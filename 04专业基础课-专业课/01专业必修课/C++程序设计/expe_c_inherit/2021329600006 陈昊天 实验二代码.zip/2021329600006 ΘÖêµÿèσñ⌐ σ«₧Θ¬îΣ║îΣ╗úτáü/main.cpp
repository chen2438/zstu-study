#pragma optimize(2)
#include "elevator.cpp"

adElevator ele(10, 1, 800);

int main() {
    UI::Start(ele);
    return 0;
}
