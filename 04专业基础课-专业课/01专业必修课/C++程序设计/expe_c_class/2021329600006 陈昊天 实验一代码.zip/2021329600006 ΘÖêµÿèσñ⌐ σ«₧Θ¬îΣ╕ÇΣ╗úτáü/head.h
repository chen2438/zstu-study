// #include <unistd.h>   //linux / mac
#include <windows.h>  //windows

#include <cstdio>
#include <cstdlib>
#include <ctime>
#include <iostream>

using std::cout;
using std::endl;
using std::string;