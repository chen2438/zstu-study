#pragma optimize(2)
#include "elevator.cpp"

Elevator ele(10, 1);

int main() {
    UI::Start(ele);
    return 0;
}
