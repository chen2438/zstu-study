var app = angular.module('myApp', []);
	
app.controller('myCtrl1', function($scope, $http) {
	$scope.username ='';
    $scope.password ='';
    $scope.msg = '';
    $scope.msg1 = '';
    $scope.enrollNumber  = '';
    $scope.enrollpassword = '';
	$http({
		method: 'GET',
		url: 'datalist'
	}).then(function success(response) {
			$scope.datas = response.data.GuestData;
		}, function error(response) {
			// 请求失败执行代码
	});


	$scope.judge = function(){
			for (var i =0;i<2;i++) 
			{
                if($scope.username == $scope.datas[i].number && $scope.password == $scope.datas[i].password){
                    $scope.msg = '登录成功！';
                    break;
                }else{
                    	$scope.msg = '用户名或密码错误！';
                }

			}
	};

	$scope.enroll = function(){
		$http({
		method: 'POST',
		url: 'http://10.31.66.157:8080/postfile',
		data: {"username":"12345","password":"1111"}
	}).then(function success(response) {
		$scope.msg1 = '注册成功'
		
		}, function error(response) {
			// 请求失败执行代码
	});

	};

});
