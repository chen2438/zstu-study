#include<stdio.h>

#include<math.h>

int main()

{

    float sum=0.0, up1=2.0, down1=1.0, temp;
    float up2=3.0, down2=2.0, up3, down3;
    int n;

    scanf("%d", &n);
    for(int i=0; i<n; i++){
        if(i == 0){
            temp = up1/down1;
            sum += temp;
        }
        else if(i == 1){
            temp = up2/down2;
            sum += temp;
        }
        else{
            up3 = up1+up2;
            down3 = down1 + down2;
            temp = up3/down3;
            up1 = up2;
            up2 = up3;
            down1 = down2;
            down2 = down3;
            sum += temp;
        }
    }
    printf("%.2f", sum);
    return 0;
}
