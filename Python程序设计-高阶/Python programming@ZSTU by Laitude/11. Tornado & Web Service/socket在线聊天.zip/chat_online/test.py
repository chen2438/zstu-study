#!/usr/bin/python3
# -*- coding: utf-8 -*-
# @Time    : 18-11-8 下午7:30
# @Author  : KainHuck
# @Email   : kainhoo2333@gmail.com
# @File    : test.py
# @Software: PyCharm

import datetime
import time

# timee = datetime.datetime.now()
timee = time.ctime()
print(timee)










