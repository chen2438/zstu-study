import hashlib

def cal(file_path, Bytes=1024): 
    md5_1 = hashlib.md5()  # 创建一个md5算法对象
    with open(file_path, 'rb') as f: # 打开文件，字节模式
        while True:
            data = f.read(Bytes) # 读取指定字节长度内容
            if data:
                md5_1.update(data)
            else:    # 当读完整个文件后，停止update
                break
    result = md5_1.hexdigest() # 获取这个文件的MD5值
    return result

print(cal("md5文件摘要.txt"))