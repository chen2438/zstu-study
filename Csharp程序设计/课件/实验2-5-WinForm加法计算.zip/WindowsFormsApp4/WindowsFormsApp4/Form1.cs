﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp4
{
    public partial class Form1 : Form
    {
        private int left = 0;
        private int right = 0;
        private Random rd = new Random();
        public Form1()
        {
            InitializeComponent();
        }

        private void GenerateValue()
        {
            left = rd.Next(1, 11);
            right = rd.Next(1, 21);
        }

        private void SetValue()
        {
            labelLeft.Text = left.ToString();
            labelRight.Text = right.ToString();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            GenerateValue();
            SetValue();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string strResult = textBoxResult.Text;
            if (strResult.Length == 0)
            {
                labelInfo.Text = "评价：未输入结果！";
                return;
            }

            int result = 0;
            try
            {
                result = int.Parse(strResult);
            }
            catch(Exception ex)
            {
                labelInfo.Text = "评价：输入有误 ——" + ex.Message;
                return;
            }

            if (left + right == result)
            {
                labelInfo.Text = "评价：计算正确！";
            }
            else
            {
                labelInfo.Text = "评价：计算错误！";
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            GenerateValue();
            SetValue();
        }
    }
}
